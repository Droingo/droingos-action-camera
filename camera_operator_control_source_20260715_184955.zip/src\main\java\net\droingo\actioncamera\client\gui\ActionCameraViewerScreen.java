package net.droingo.actioncamera.client.gui;

import net.droingo.actioncamera.client.ActionCameraClientState;
import net.droingo.actioncamera.client.ClientGameEvents;
import net.droingo.actioncamera.world.blockentity.ActionCameraBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public final class ActionCameraViewerScreen extends Screen {
    private static final int PANEL_MARGIN = 8;
    private static final int PANEL_WIDTH = 255;
    private static final int HEADER_HEIGHT = 28;
    private static final int INNER_PADDING = 7;
    private static final int WIDGET_HEIGHT = 20;
    private static final int GROUP_ROW_HEIGHT = 17;
    private static final int CAMERA_ROW_HEIGHT = 22;
    private static final int MAX_LIST_HEIGHT = 165;
    private static final int REFRESH_INTERVAL = 10;

    private final List<CameraEntry> cameras = new ArrayList<>();
    private final List<VisibleRow> rows = new ArrayList<>();
    private final Set<String> expandedGroups = new HashSet<>();

    private EditBox searchBox;
    private Button sortButton;
    private Button dropdownButton;
    private SortMode sortMode = SortMode.DISTANCE;
    private BlockPos selectedCameraPos;
    private int scrollPixels;
    private int refreshTicks;
    private boolean expanded = true;
    private boolean memoryRestored;
    private boolean initialCameraChosen;
    private boolean everViewedCamera;
    private boolean closing;

    private ActionCameraViewerMemory.Snapshot rememberedState =
            new ActionCameraViewerMemory.Snapshot(null, null, 0, Set.of());

    private ActionCameraViewerScreen() {
        super(Component.literal("Camera Viewer"));
    }

    public static void open() {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) return;
        if (minecraft.screen instanceof ActionCameraViewerScreen) return;
        minecraft.setScreen(new ActionCameraViewerScreen());
    }

    @Override
    protected void init() {
        super.init();
        int controlsWidth = getPanelWidth() - INNER_PADDING * 2;
        int searchWidth = Math.max(70, controlsWidth - 77);
        int x = PANEL_MARGIN + INNER_PADDING;
        int y = PANEL_MARGIN + HEADER_HEIGHT + 5;

        searchBox = addRenderableWidget(new EditBox(font, x, y, searchWidth, WIDGET_HEIGHT,
                Component.literal("Search cameras")));
        searchBox.setHint(Component.literal("Search..."));
        searchBox.setMaxLength(64);
        searchBox.setResponder(value -> {
            scrollPixels = 0;
            rebuild();
        });

        sortButton = addRenderableWidget(Button.builder(sortLabel(), button -> {
            sortMode = sortMode.next();
            button.setMessage(sortLabel());
            scrollPixels = 0;
            rebuild();
        }).bounds(x + searchWidth + 5, y, 72, WIDGET_HEIGHT).build());

        dropdownButton = addRenderableWidget(Button.builder(Component.literal("v"),
                button -> setExpanded(!expanded))
                .bounds(getPanelRight() - 25, PANEL_MARGIN + 4, 21, 20).build());

        addRenderableWidget(Button.builder(Component.literal("X"), button -> exitViewer())
                .bounds(width - 28, 8, 20, 20).build());

        addRenderableWidget(Button.builder(Component.literal("<"), button -> cycleCamera(-1))
                .bounds(8, Math.max(36, height / 2 - 10), 20, 20).build());
        addRenderableWidget(Button.builder(Component.literal(">"), button -> cycleCamera(1))
                .bounds(width - 28, Math.max(36, height / 2 - 10), 20, 20).build());

        if (!memoryRestored) {
            rememberedState = ActionCameraViewerMemory.getSnapshot(Minecraft.getInstance());
            selectedCameraPos = copy(rememberedState.lastSelectedCamera());
            scrollPixels = Math.max(0, rememberedState.scrollRows());
            expandedGroups.addAll(rememberedState.expandedGroups());
            memoryRestored = true;
        }

        rebuild();
        if (!initialCameraChosen) {
            chooseInitialCamera();
            initialCameraChosen = true;
        }
        updateWidgetVisibility();
    }

    private void setExpanded(boolean value) {
        expanded = value;
        if (expanded) rebuild();
        updateWidgetVisibility();
    }

    private void updateWidgetVisibility() {
        if (searchBox == null || sortButton == null || dropdownButton == null) return;
        searchBox.visible = expanded;
        searchBox.active = expanded;
        sortButton.visible = expanded;
        sortButton.active = expanded;
        dropdownButton.setMessage(Component.literal(expanded ? "v" : ">"));
        if (!expanded) {
            searchBox.setFocused(false);
            setFocused(null);
        }
    }

    private void chooseInitialCamera() {
        BlockPos target = null;
        BlockPos active = ActionCameraClientState.getActiveCameraPos();
        if (isCamera(active)) target = active;
        if (target == null && isCamera(rememberedState.lastViewedCamera())) target = rememberedState.lastViewedCamera();
        if (target == null) {
            BlockPos lookedAt = ClientGameEvents.getLookedAtCameraPos(Minecraft.getInstance());
            if (isCamera(lookedAt)) target = lookedAt;
        }
        if (target == null && !cameras.isEmpty()) target = cameras.get(0).position();
        if (target != null) {
            selectCamera(target, false);
            if (selectedCameraPos == null) selectedCameraPos = target.immutable();
        }
    }

    private void selectCamera(BlockPos position, boolean expandGroup) {
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.level == null || position == null) return;
        BlockEntity blockEntity = minecraft.level.getBlockEntity(position);
        if (!(blockEntity instanceof ActionCameraBlockEntity camera)) return;

        selectedCameraPos = position.immutable();
        ActionCameraClientState.startViewing(selectedCameraPos, camera.getCameraName());
        everViewedCamera = true;
        ActionCameraViewerMemory.rememberViewedCamera(minecraft, selectedCameraPos);
        ActionCameraViewerMemory.rememberSelectedCamera(minecraft, selectedCameraPos);

        if (expandGroup) {
            expandedGroups.add(groupKey(camera.getCameraGroup()));
            ActionCameraViewerMemory.rememberExpandedGroups(minecraft, expandedGroups);
            rebuildRows();
        }
    }

    private void cycleCamera(int direction) {
        if (cameras.isEmpty()) return;
        BlockPos active = ActionCameraClientState.getActiveCameraPos();
        int index = -1;
        for (int i = 0; i < cameras.size(); i++) {
            if (cameras.get(i).position().equals(active)) {
                index = i;
                break;
            }
        }
        int next = Math.floorMod(index + direction, cameras.size());
        selectCamera(cameras.get(next).position(), true);
    }

    private void rebuild() {
        Minecraft minecraft = Minecraft.getInstance();
        cameras.clear();
        if (minecraft.player == null || minecraft.level == null) {
            rows.clear();
            return;
        }

        String filter = searchBox == null ? "" : searchBox.getValue().trim().toLowerCase(Locale.ROOT);

        for (Object value : ClientGameEvents.collectKnownCameraPositions(minecraft)) {
            if (!(value instanceof BlockPos position)) continue;
            BlockEntity blockEntity = minecraft.level.getBlockEntity(position);
            if (!(blockEntity instanceof ActionCameraBlockEntity camera)) continue;

            String name = normalizeName(camera.getCameraName());
            String group = normalizeGroup(camera.getCameraGroup());
            if (!filter.isEmpty()
                    && !name.toLowerCase(Locale.ROOT).contains(filter)
                    && !group.toLowerCase(Locale.ROOT).contains(filter)) continue;

            cameras.add(new CameraEntry(position.immutable(), name, group, camera.getCameraGroupColor()));
        }

        if (sortMode == SortMode.ALPHABETICAL) {
            cameras.sort(Comparator.comparing(CameraEntry::group, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(CameraEntry::name, String.CASE_INSENSITIVE_ORDER)
                    .thenComparingLong(entry -> entry.position().asLong()));
        }

        rebuildRows();
    }

    private void rebuildRows() {
        rows.clear();
        String filter = searchBox == null ? "" : searchBox.getValue().trim();

        Map<String, List<CameraEntry>> groups = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
        for (CameraEntry camera : cameras) {
            groups.computeIfAbsent(camera.group(), ignored -> new ArrayList<>()).add(camera);
        }

        for (Map.Entry<String, List<CameraEntry>> entry : groups.entrySet()) {
            String group = entry.getKey();
            List<CameraEntry> children = entry.getValue();
            int color = children.isEmpty() ? ActionCameraBlockEntity.DEFAULT_GROUP_COLOR : children.get(0).color();
            boolean open = !filter.isEmpty() || expandedGroups.contains(groupKey(group));
            rows.add(VisibleRow.group(group, children.size(), color, open));
            if (open) {
                for (CameraEntry camera : children) rows.add(VisibleRow.camera(camera));
            }
        }
        clampScroll();
    }

    @Override
    public void tick() {
        super.tick();
        if (closing) return;
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player == null || minecraft.level == null) {
            closeScreenOnly();
            return;
        }
        if (everViewedCamera && !ActionCameraClientState.isViewingCamera()) {
            closeScreenOnly();
            return;
        }
        if (++refreshTicks >= REFRESH_INTERVAL) {
            refreshTicks = 0;
            rebuild();
        }
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button != GLFW.GLFW_MOUSE_BUTTON_LEFT || !expanded || !insideList(mouseX, mouseY)) return false;

        int contentY = (int) mouseY - getListTop() + scrollPixels;
        int cursor = 0;
        for (VisibleRow row : rows) {
            int h = row.height();
            if (contentY >= cursor && contentY < cursor + h) {
                if (row.groupHeader()) {
                    String key = groupKey(row.groupName());
                    if (expandedGroups.contains(key)) expandedGroups.remove(key);
                    else expandedGroups.add(key);
                    ActionCameraViewerMemory.rememberExpandedGroups(Minecraft.getInstance(), expandedGroups);
                    rebuildRows();
                } else {
                    selectCamera(row.camera().position(), false);
                }
                return true;
            }
            cursor += h;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        if (expanded && insideList(mouseX, mouseY)) {
            scrollPixels -= (int) Math.signum(verticalAmount) * CAMERA_ROW_HEIGHT;
            clampScroll();
            ActionCameraViewerMemory.rememberScrollRows(Minecraft.getInstance(), scrollPixels);
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
            exitViewer();
            return true;
        }
        boolean typing = searchBox != null && searchBox.isFocused();
        if (!typing && (keyCode == GLFW.GLFW_KEY_LEFT_SHIFT || keyCode == GLFW.GLFW_KEY_RIGHT_SHIFT)) {
            exitViewer();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override public void onClose() { exitViewer(); }

    @Override
    public void removed() {
        remember();
        if (!closing && ActionCameraClientState.isViewingCamera()) ActionCameraClientState.stopViewing();
        super.removed();
    }

    private void exitViewer() {
        if (closing) return;
        closing = true;
        remember();
        if (ActionCameraClientState.isViewingCamera()) ActionCameraClientState.stopViewing();
        Minecraft.getInstance().setScreen(null);
    }

    private void closeScreenOnly() {
        if (closing) return;
        closing = true;
        remember();
        Minecraft.getInstance().setScreen(null);
    }

    private void remember() {
        Minecraft minecraft = Minecraft.getInstance();
        BlockPos active = ActionCameraClientState.getActiveCameraPos();
        if (active != null) ActionCameraViewerMemory.rememberViewedCamera(minecraft, active);
        if (selectedCameraPos != null) ActionCameraViewerMemory.rememberSelectedCamera(minecraft, selectedCameraPos);
        ActionCameraViewerMemory.rememberScrollRows(minecraft, scrollPixels);
        ActionCameraViewerMemory.rememberExpandedGroups(minecraft, expandedGroups);
    }

    @Override public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {}

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        int panelBottom = expanded ? getListBottom() + 4 : PANEL_MARGIN + HEADER_HEIGHT;
        g.fill(PANEL_MARGIN, PANEL_MARGIN, getPanelRight(), panelBottom, 0xC8000000);
        g.fill(PANEL_MARGIN + 1, PANEL_MARGIN + 1, PANEL_MARGIN + 4, panelBottom - 1, 0xFF4E91B8);

        String header = "CAMERAS " + cameras.size() + " | " + currentCameraName();
        g.drawString(font, trim(header, getPanelWidth() - 42), PANEL_MARGIN + INNER_PADDING,
                PANEL_MARGIN + 10, 0xFFFFFFFF, false);

        if (expanded) renderRows(g, mouseX, mouseY);
        super.render(g, mouseX, mouseY, partialTick);
    }

    private void renderRows(GuiGraphics g, int mouseX, int mouseY) {
        int left = PANEL_MARGIN + INNER_PADDING;
        int right = getPanelRight() - INNER_PADDING;
        int top = getListTop();
        int bottom = getListBottom();
        g.fill(left, top, right, bottom, 0x780B0B0B);
        g.enableScissor(left, top, right, bottom);

        BlockPos active = ActionCameraClientState.getActiveCameraPos();
        int y = top - scrollPixels;

        for (VisibleRow row : rows) {
            int h = row.height();
            if (y + h >= top && y <= bottom) {
                if (row.groupHeader()) {
                    boolean open = row.open();
                    g.fill(left + 1, y + 1, right - 1, y + h - 1, 0xA0282828);
                    g.fill(left + 1, y + 1, left + 4, y + h - 1, 0xFF000000 | (row.color() & 0xFFFFFF));
                    g.drawString(font, open ? "v" : ">", left + 7, y + 5, 0xFFFFFFFF, false);
                    String label = row.groupName() + " (" + row.count() + ")";
                    g.drawString(font, trim(label, right - left - 24), left + 18, y + 5, 0xFFE5E5E5, false);
                } else {
                    CameraEntry camera = row.camera();
                    boolean current = active != null && active.equals(camera.position());
                    boolean hover = mouseX >= left && mouseX < right && mouseY >= y && mouseY < y + h;
                    int bg = current ? 0xD0447391 : hover ? 0xA0383838 : 0x70202020;
                    g.fill(left + 8, y + 1, right - 1, y + h - 1, bg);
                    g.drawString(font, trim(camera.name(), right - left - 56), left + 15, y + 4,
                            current ? 0xFFFFFFFF : 0xFFE1E1E1, false);
                    if (current) g.drawString(font, "LIVE", right - 28, y + 4, 0xFFB8E8FF, false);
                    String coords = camera.position().getX() + ", " + camera.position().getY() + ", " + camera.position().getZ();
                    g.drawString(font, coords, left + 15, y + 14, 0xFF999999, false);
                }
            }
            y += h;
        }
        g.disableScissor();
    }

    private void clampScroll() {
        int max = Math.max(0, contentHeight() - MAX_LIST_HEIGHT);
        scrollPixels = Math.max(0, Math.min(scrollPixels, max));
    }

    private int contentHeight() {
        int value = 0;
        for (VisibleRow row : rows) value += row.height();
        return value;
    }

    private boolean insideList(double x, double y) {
        return x >= PANEL_MARGIN + INNER_PADDING && x < getPanelRight() - INNER_PADDING
                && y >= getListTop() && y < getListBottom();
    }

    private boolean isCamera(BlockPos pos) {
        Minecraft minecraft = Minecraft.getInstance();
        return pos != null && minecraft.level != null
                && minecraft.level.getBlockEntity(pos) instanceof ActionCameraBlockEntity;
    }

    private String currentCameraName() {
        Minecraft minecraft = Minecraft.getInstance();
        BlockPos active = ActionCameraClientState.getActiveCameraPos();
        if (minecraft.level != null && active != null
                && minecraft.level.getBlockEntity(active) instanceof ActionCameraBlockEntity camera) {
            return normalizeName(camera.getCameraName());
        }
        return "No camera";
    }

    private int getPanelWidth() { return Math.max(205, Math.min(PANEL_WIDTH, width - 44)); }
    private int getPanelRight() { return PANEL_MARGIN + getPanelWidth(); }
    private int getListTop() { return PANEL_MARGIN + HEADER_HEIGHT + 30; }
    private int getListBottom() { return getListTop() + MAX_LIST_HEIGHT; }
    private Component sortLabel() { return Component.literal(sortMode == SortMode.DISTANCE ? "Distance" : "A-Z"); }

    private String trim(String text, int maxWidth) {
        if (font.width(text) <= maxWidth) return text;
        String value = text;
        while (!value.isEmpty() && font.width(value + "...") > maxWidth) value = value.substring(0, value.length() - 1);
        return value + "...";
    }

    private static String normalizeName(String value) {
        return value == null || value.isBlank() ? "Action Camera" : value.trim();
    }

    private static String normalizeGroup(String value) {
        return value == null || value.isBlank() ? "Ungrouped" : value.trim();
    }

    private static String groupKey(String value) { return normalizeGroup(value).toLowerCase(Locale.ROOT); }
    private static BlockPos copy(BlockPos value) { return value == null ? null : value.immutable(); }

    @Override public boolean isPauseScreen() { return false; }

    private enum SortMode {
        DISTANCE, ALPHABETICAL;
        private SortMode next() { return this == DISTANCE ? ALPHABETICAL : DISTANCE; }
    }

    private record CameraEntry(BlockPos position, String name, String group, int color) {}

    private record VisibleRow(boolean groupHeader, String groupName, int count, int color,
                              boolean open, CameraEntry camera, int height) {
        static VisibleRow group(String name, int count, int color, boolean open) {
            return new VisibleRow(true, name, count, color, open, null, GROUP_ROW_HEIGHT);
        }
        static VisibleRow camera(CameraEntry camera) {
            return new VisibleRow(false, "", 0, 0, false, camera, CAMERA_ROW_HEIGHT);
        }
    }
}
